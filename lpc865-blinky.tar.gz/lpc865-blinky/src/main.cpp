
#include <stdint.h>
#define GPIO0_BASE 0xA0000000
#define GPIO_DIR (*(volatile uint32_t*)(GPIO0_BASE + 0x2000))
#define GPIO_SET (*(volatile uint32_t*)(GPIO0_BASE + 0x2200))
#define GPIO_CLR (*(volatile uint32_t*)(GPIO0_BASE + 0x2280))

extern "C" void delay() {
    for (volatile int i = 0; i < 100000; ++i);
}

int main() {
    GPIO_DIR |= (1 << 0); // Set PIO0_0 as output
    while (1) {
        GPIO_SET = (1 << 0); // LED on
        delay();
        GPIO_CLR = (1 << 0); // LED off
        delay();
    }
    return 0;
}
